package in.sandip.reader;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MessageReader {

	@JmsListener(destination = "sample")
	public void readMsg(String message) {
		System.out.println(" Data at consumer => " + message);
	}
}
