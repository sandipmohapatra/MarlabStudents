package in.sandip.runner;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class MessageSender {  // implements CommandLineRunner {
	@Autowired
	private JmsTemplate jt;
	@Value("${my.mq.desti-name}")
	private String destinationName;

	//@Override
	//public void run(String... args) throws Exception {
	@Scheduled(cron = "0 */1 * * * *")
public void send()
{
		jt.send(	destinationName,
				//message creator object
				ses -> ses.createTextMessage(
						"HELLO FROM PRODUCER=>"+new Date()) 
				);

	
	}

}
