package in.sandip;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;
@RestController
@RequestMapping("/gst")
public class GstRestController {
	
	@Value("${server.port}")
	private String port;
	
	@GetMapping("/data")
	public String getDetails() 
	{
		int id=101;
		String name="Samsung TV";
		double price=45000.56;
		System.out.println("product id :"+id);
		System.out.println("product name :"+name);
		System.out.println("product price:"+price);
		double gst=price*0.18;
		double total=price+gst;
		return "Total With  GST = "+total+" " + "port :"+port;
	}
}
