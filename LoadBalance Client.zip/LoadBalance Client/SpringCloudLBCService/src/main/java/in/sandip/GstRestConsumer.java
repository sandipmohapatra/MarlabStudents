package in.sandip;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class GstRestConsumer {

	//1. Autowire LoadBalancerClient
	@Autowired
	private LoadBalancerClient client;
	
	public String getDetailsFromGst() {
		//2. get one ServiceInstance by using ServiceId
		ServiceInstance si = client.choose("GST-SERVICE");
		
		//3. Read URI from SI
		URI uri = si.getUri();
		
		//4. Add path to get URL
		String url = uri + "/gst/data";
		
		//5. Use RestTemplate
		RestTemplate rt = new RestTemplate();
		
		//6. make HTTP call
		String response = rt.getForObject(url, String.class);
		
		return response;
	}
}
