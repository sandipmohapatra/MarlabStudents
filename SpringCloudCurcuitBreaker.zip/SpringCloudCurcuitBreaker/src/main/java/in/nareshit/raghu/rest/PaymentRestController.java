package in.nareshit.raghu.rest;

import java.util.Random;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
@RequestMapping("/payment")
public class PaymentRestController {

	@GetMapping("/pay")
	
	
	@HystrixCommand(
			fallbackMethod = "doPaymentFallBack",
			commandProperties = {
					@HystrixProperty(name="circuitBreaker.requestVolumeThreshold",value = "5"),
					@HystrixProperty(name="circuitBreaker.sleepWindowInMilliseconds",value = "60000")
			})
	
	public String doPayment() {
		System.out.println("FROM ACTUAL SERVICE");
		if(new Random().nextInt(9)<10) {
			throw new RuntimeException("DUMMY EXCEPTION");
		}
		return "DONE";
	}
	
	public String doPaymentFallBack() {
		System.out.println("FROM FALLBACK SERVICE");
		return "PLEASE TRY AFTER SOMETIME!!";
	}
	
}
