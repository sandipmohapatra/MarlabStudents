export class Employee {
  constructor(
    public empId: number,
    public empName: string,
    public empSal: number,
    public empGen: string,
    public empDept: string,
    public empAddr: string
  ) {}
}
