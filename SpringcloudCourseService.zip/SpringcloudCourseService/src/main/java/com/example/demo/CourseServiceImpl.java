package com.example.demo;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseServiceImpl implements ICourseService 
{
@Autowired
private CourseRepository repo;
@Autowired
private CourseUtil util;
Course x=null;

	@Override
	public Integer saveCourse(Course c) {
		util.calculateGst(c);
		c=repo.save(c);
		return c.getCid();
	}

	@Override
	public List<Course> getAllCourse() {
		List x=(List) repo.findAll();
		return x;
	}

	@Override
	public Course getOneCourse(Integer id) {
	Optional<Course> opt=repo.findById(id);
		return opt.get();
	}

}
