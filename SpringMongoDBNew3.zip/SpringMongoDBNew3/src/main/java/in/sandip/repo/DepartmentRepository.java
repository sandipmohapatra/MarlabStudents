package in.sandip.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import in.sandip.collection.Department;

public interface DepartmentRepository extends MongoRepository<Department, Integer> {

}
