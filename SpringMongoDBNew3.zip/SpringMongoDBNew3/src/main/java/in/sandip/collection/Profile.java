package in.sandip.collection;

public class Profile {

	private String code;
	private String format;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public Profile(String code, String format) {
		super();
		this.code = code;
		this.format = format;
	}
	public Profile() {
		super();
	}
	
}
