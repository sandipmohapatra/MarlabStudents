package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMongoDb2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMongoDb2Application.class, args);
	}

}
