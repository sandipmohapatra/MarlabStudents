package com.sandip.runner;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.sandip.model.Address;
import com.sandip.model.Department;
import com.sandip.model.Employee;
import com.sandip.model.Profile;
import com.sandip.repo.DepartmentRepository;
import com.sandip.repo.EmployeeRepository;

@Component
public class TestRunner implements CommandLineRunner
{
@Autowired
private EmployeeRepository repo;
@Autowired
private DepartmentRepository depo;
	@Override
	public void run(String... args) throws Exception
	{
		repo.deleteAll();
		Department d1=new Department(1001,"Developer");
		depo.save(d1);
		
				
		repo.save(new Employee(101,"sandip",Arrays.asList("project1","project2","project3"),
				Map.of("client1","Microsoft","client2","Amazon"),new Address("10/A","Banjara Hills","Hydrabad"),
				Arrays.asList(new Profile("profile1","Resume1"),new Profile("profile2","Resume2")),d1
				)
				);
		
	}

}
