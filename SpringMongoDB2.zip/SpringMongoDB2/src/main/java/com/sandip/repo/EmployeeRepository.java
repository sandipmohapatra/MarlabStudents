package com.sandip.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.sandip.model.Employee;

public interface EmployeeRepository extends MongoRepository<Employee,Integer> 
{

}
