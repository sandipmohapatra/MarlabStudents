package com.sandip.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.sandip.model.Department;

public interface DepartmentRepository extends MongoRepository<Department,Integer>  
{

}
