package com.sandip.model;

public class Address 
{
private String houseno;
private String loc;
private String city;
public String getHouseno() {
	return houseno;
}
public void setHouseno(String houseno) {
	this.houseno = houseno;
}
public String getLoc() {
	return loc;
}
public void setLoc(String loc) {
	this.loc = loc;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public Address(String houseno, String loc, String city) {
	super();
	this.houseno = houseno;
	this.loc = loc;
	this.city = city;
}
@Override
public String toString() {
	return "Address [houseno=" + houseno + ", loc=" + loc + ", city=" + city + "]";
}

}
