package com.sandip.model;
import java.util.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="Myemployees")
public class Employee 
{
@Id
private Integer id;
private String name;
private List<String> projs;
private Map<String,String> clients;
private Address addr;
private List<Profile> pros;
@DBRef
private Department dob;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<String> getProjs() {
	return projs;
}
public void setProjs(List<String> projs) {
	this.projs = projs;
}
public Map<String, String> getClients() {
	return clients;
}
public void setClients(Map<String, String> clients) {
	this.clients = clients;
}
public Address getAddr() {
	return addr;
}
public void setAddr(Address addr) {
	this.addr = addr;
}
public List<Profile> getPros() {
	return pros;
}
public void setPros(List<Profile> pros) {
	this.pros = pros;
}
public Department getDob() {
	return dob;
}
public void setDob(Department dob) {
	this.dob = dob;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", projs=" + projs + ", clients=" + clients + ", addr=" + addr
			+ ", pros=" + pros + ", dob=" + dob + "]";
}
public Employee(Integer id, String name, List<String> projs, Map<String, String> clients, Address addr,
		List<Profile> pros, Department dob) {
	super();
	this.id = id;
	this.name = name;
	this.projs = projs;
	this.clients = clients;
	this.addr = addr;
	this.pros = pros;
	this.dob = dob;
}
public Employee() {
	super();
}

	
}
