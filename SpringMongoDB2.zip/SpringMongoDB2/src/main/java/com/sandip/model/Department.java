package com.sandip.model;

import org.springframework.data.annotation.Id;

public class Department 
{
@Id
private Integer id;
private String code;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public Department(Integer id, String code) {
	super();
	this.id = id;
	this.code = code;
}
@Override
public String toString() {
	return "Department [id=" + id + ", code=" + code + "]";
}
public Department() {
	super();
}



}
