package com.example.demo;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
@Component
public class TestMongodb implements CommandLineRunner
{
@Autowired
private EmployeeRepository repo;
	@Override
	public void run(String... args) throws Exception {
	Employee emp=new Employee();
	Scanner ob=new Scanner(System.in);
	System.out.println("enter id,empid,name,salary");
		String id=ob.next();
		int eid=ob.nextInt();
		String name=ob.next();
		Double sal=ob.nextDouble();
		
		emp.setId(id);emp.setEid(eid);emp.setEname(name);emp.setEsal(sal);
		repo.save(emp);
	}

}
