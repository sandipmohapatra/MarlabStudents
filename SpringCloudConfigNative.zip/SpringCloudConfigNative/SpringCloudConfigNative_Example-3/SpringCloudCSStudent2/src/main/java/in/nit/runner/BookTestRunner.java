package in.nit.runner;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.nit.model.Author;
import in.nit.model.Book;
import in.nit.repo.AuthorRepository;
import in.nit.repo.BookRepository;

@Component
public class BookTestRunner implements CommandLineRunner {
	
	@Autowired
	private BookRepository repo;
	
	@Autowired
	private AuthorRepository authRepo;
	
	@Override
	public void run(String... args) throws Exception {
		Book book = new Book();
		book.setBookId(5501);
		book.setBookName("HEAD FIRST JAVA");
		book.setBookCost(500.25);
		book.setAuthList(
				Arrays.asList(
						authRepo.findByAuthId(101),
						authRepo.findByAuthId(103)
						)
				);
		
		
		repo.save(book);
		
	}
}



