package in.nit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity

public class Author {
	@Id
		
	private Integer authId;
	public Author( Integer authId, String authFname, String authLname, String authInfo) {
		super();
		this.authId = authId;
		this.authFname = authFname;
		this.authLname = authLname;
		this.authInfo = authInfo;
	}
	public Integer getAuthId() {
		return authId;
	}
	public void setAuthId(Integer authId) {
		this.authId = authId;
	}
	public String getAuthFname() {
		return authFname;
	}
	public void setAuthFname(String authFname) {
		this.authFname = authFname;
	}
	public String getAuthLname() {
		return authLname;
	}
	public void setAuthLname(String authLname) {
		this.authLname = authLname;
	}
	public String getAuthInfo() {
		return authInfo;
	}
	public void setAuthInfo(String authInfo) {
		this.authInfo = authInfo;
	}
	private String authFname;
	private String authLname;
	private String authInfo;
	
}
