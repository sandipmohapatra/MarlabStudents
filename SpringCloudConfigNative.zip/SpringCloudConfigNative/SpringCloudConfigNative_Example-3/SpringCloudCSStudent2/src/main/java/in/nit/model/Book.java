package in.nit.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "book2")
public class Book {
	@Id
	
	private Integer bookId;
	public Book() {
		super();
	}

	public Book(Integer bookId, String bookName, Double bookCost, List<Author> authList) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookCost = bookCost;
		this.authList = authList;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public Double getBookCost() {
		return bookCost;
	}

	public void setBookCost(Double bookCost) {
		this.bookCost = bookCost;
	}

	public List<Author> getAuthList() {
		return authList;
	}

	public void setAuthList(List<Author> authList) {
		this.authList = authList;
	}

	private String bookName;
	private Double bookCost;
	
	@OneToMany
	@JoinColumn(name="bookIdFk")
	private List<Author> authList;
}
