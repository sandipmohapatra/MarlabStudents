package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import in.nit.model.Author;
import in.nit.repo.AuthorRepository;

//@Component
public class AuthorTestRunner implements CommandLineRunner {
	@Autowired
	private AuthorRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		repo.save(new Author(101, "SAM", "KARAN", "Java Author"));
		repo.save(new Author(102, "VIJAY", "KRISHNA", "Boot Author"));
		repo.save(new Author(103, "MD", "SYED", "SPRING Author"));
		repo.save(new Author(104, "SAJNU", "SAM", "ADV JAVA Author"));
		
	}

}
