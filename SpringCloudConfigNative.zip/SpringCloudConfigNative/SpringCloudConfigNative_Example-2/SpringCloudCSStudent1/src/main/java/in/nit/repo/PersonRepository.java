package in.nit.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nit.model.Person;

public interface PersonRepository extends JpaRepository<Person, Integer> {

}
