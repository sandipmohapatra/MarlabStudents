package in.nit.runner;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import in.nit.model.PanCard;
import in.nit.repo.PanCardRepository;

@Component
@Order(10)
public class PanCardRunner implements CommandLineRunner {
	@Autowired
	private PanCardRepository repo;
	
	@Override
	public void run(String... args) throws Exception {
		
		repo.save(new PanCard(1025, "DDMMS1199L", "A", new Date(System.currentTimeMillis())));
		repo.save(new PanCard(1026, "RRMMS1100T", "B", new Date(System.currentTimeMillis())));
		repo.save(new PanCard(1027, "DDPPS1198T", "C", new Date(System.currentTimeMillis())));
	}

}
