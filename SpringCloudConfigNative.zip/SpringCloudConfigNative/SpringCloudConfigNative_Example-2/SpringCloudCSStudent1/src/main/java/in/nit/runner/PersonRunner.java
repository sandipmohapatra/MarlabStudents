package in.nit.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import in.nit.model.Person;
import in.nit.repo.PanCardRepository;
import in.nit.repo.PersonRepository;

@Component
@Order(20)
public class PersonRunner implements CommandLineRunner {

	@Autowired
	private PersonRepository repo;
	@Autowired
	private PanCardRepository panRepo;
	
	@Override
	public void run(String... args) throws Exception {
		Person p1 = new Person(); 
		p1.setPerId(10);
		p1.setPerName("A");
		p1.setPerGender("Male");
		p1.setPerAddr("HYD");
		p1.setCard(panRepo.findByPanId(1025));
		
		repo.save(p1);
		
		
		Person p2 = new Person(); 
		p2.setPerId(11);
		p2.setPerName("B");
		p2.setPerGender("Male");
		p2.setPerAddr("BAN");
		p2.setCard(panRepo.findByPanId(1026));
		
		
		repo.save(p2);
		
		
		Person p3 = new Person(); 
		p3.setPerId(12);
		p3.setPerName("C");
		p3.setPerGender("Female");
		p3.setPerAddr("CHN");
		p3.setCard(panRepo.findByPanId(1027));
		
		
		repo.save(p3);
	}

}


