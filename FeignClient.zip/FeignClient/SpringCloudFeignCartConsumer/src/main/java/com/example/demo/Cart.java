package com.example.demo;

public class Cart 
{
private Integer id;
private String code;
private Double cost;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public Double getCost() {
	return cost;
}
public void setCost(Double cost) {
	this.cost = cost;
}
public Cart(Integer id, String code, Double cost) {
	super();
	this.id = id;
	this.code = code;
	this.cost = cost;
}
public Cart() {
	super();
}
@Override
public String toString() {
	return "Cart [id=" + id + ", code=" + code + ", cost=" + cost + "]";
}

}
