package com.example.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@FeignClient("CART-SERVICE")
public interface CartRestConsumer {
@GetMapping("/cart/msg")
public String findMsg();

@GetMapping("/cart/ob/{code}")
public String findCart(@PathVariable String code);

@PostMapping("/cart/insert")
public ResponseEntity<String> createCart(@RequestBody Cart cart);
}
