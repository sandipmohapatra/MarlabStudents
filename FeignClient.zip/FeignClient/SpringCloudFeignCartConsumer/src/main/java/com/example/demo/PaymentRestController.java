package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/pay")
public class PaymentRestController 
{
@Autowired
private CartRestConsumer cons;

@GetMapping("/msg")
public String getPayMsg()
{
	return "from payment "+cons.findMsg();
}

@GetMapping("/ob")
public String getCartCord()
{
	return "from payment "+cons.findCart("Sumsung TV");
}

@PostMapping("/create")
public String createCart()
{
	return "from payment "+cons.createCart(new Cart(101,"Samsung Refrizerator",17500.34));
}



}
