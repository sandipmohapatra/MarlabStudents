package com.sandip;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class Test 
{
public static void main(String[] args) 
{
Resource ctx=new ClassPathResource("applicationContext.xml");
BeanFactory fact=new XmlBeanFactory(ctx);

EmployeeDao dao=(EmployeeDao)fact.getBean("edao");
dao.saveEmployee(new Employee(105,"Kiran",45000.00f));
System.out.println("Row Inserted");


}
}
