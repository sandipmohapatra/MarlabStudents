package in.sandip;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/student")
public class StudentRestController {

	@Autowired
	private IStudentService service;
	
	@Autowired
	private CourseRestConsumer consumer;
	
	@PostMapping
	public ResponseEntity<String> saveStudent(
			@RequestBody Student student)
	{
		ResponseEntity<String> resp = null;
		try {
			//read Course ID from JSON Object and get Full Course Object
			Course cob = consumer.getCourseById(student.getCob().getCid()).getBody();
			//Link actual course object with Student object.
			student.setCob(cob);
			Integer id = service.saveStudent(student);
			resp = ResponseEntity.ok("Student '"+id+"' saved");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(resp);
		return resp;
	}
	@GetMapping("/all")
	public List<Student> getAllStudents()
	{
		List<Student> allStudents=service.getAllStudents();
		return allStudents;
			}	
	
}
