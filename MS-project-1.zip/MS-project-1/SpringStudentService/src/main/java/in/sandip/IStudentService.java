package in.sandip;

import java.util.List;

public interface IStudentService {

	public Integer saveStudent(Student s);
	public List<Student> getAllStudents();
}
