package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/address")
public class AddressController 
{
@GetMapping("/show")
public String showMsg()
{
	String address="My address is Bangalore";
	System.out.println("Hello welcome to Bangalore");
	return address;
	
}
}
