package com.cognizant;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import com.cognizant.model.Book;
import com.cognizant.model.Subject;
import com.cognizant.repository.EntityDao;
import com.cognizant.repository.EntityDaoImpl;

public class Application {
	private EntityDao entityDao;

	Application() {
		this.entityDao = new EntityDaoImpl();
		while (true) {
			System.out.println("\n");
			System.out.println("1.Add a Subject");
			System.out.println("2.Add a Book");
			System.out.println("3.Delete a Subject");
			System.out.println("4.Delete a book");
			System.out.println("5.Search for a subject");
			System.out.println("6.Search for a book");
			System.out.println("7.Sort Book by Title");
			System.out.println("8.Sort Subject by Subject Title");
			System.out.println("9.Sort Books by publish Date");
			System.out.println("10.Show All");
			System.out.println("11.Exit");

		String input = gatValFromConsole("please select menu items::::::::::::::::");
			select(Integer.parseInt(input));
		}
	}
	
	public static void main(String[] args) {	
		new Application();		
	}
	
	public void select(int i) {
		switch(i) {
		case 1: entityDao.addSubject(addSubject());
		break;
		case 2: entityDao.addBook(addBook());
		break;
		case 3: entityDao.deleteSubject(deleteSubject());
		break;
		case 4: entityDao.deleteBook(deleteBook());
		break;
		case 5: Subject subject=entityDao.searchSubject(searchSubject());
				System.out.println("Result :"+subject);
		break;
		case 6: Book book=entityDao.searchBook(searchBook());
				System.out.println("Result :"+book);
		break;
		case 7: sortBookByTitle();
		break;
		case 8: sortSubjectByTitle();
		break;
		case 9: sortBookByPublishDate();
		break;	
		case 10: showAll();
		break;
		case 11: exit();
		break;
		}	
	}

	private void sortBookByTitle() {		
		System.out.println("\n");
		System.out.println("<------Book List Sort by book title------->");
		entityDao.sortBookByTitle().stream().forEach(System.out::println);
	}
	
	private void sortSubjectByTitle() {		
		System.out.println("\n");
		System.out.println("<------Subject List Sort by Subject Title------->");
		entityDao.sortSubjectByTitle().stream().forEach(System.out::println);
	}
	
	private void sortBookByPublishDate() {		
		System.out.println("\n");
		System.out.println("<------Book List Sort by Publish Date------->");
		entityDao.sortBookByPublishDate().stream().forEach(System.out::println);
	}
	
	private void showAll() {		
		System.out.println("\n");
		System.out.println("<------Total Subject List------->");
		entityDao.showAllSubjects().stream().forEach(System.out::println);
		System.out.println("\n");
		System.out.println("<------Total Book List------->");
		entityDao.showAllBooks().stream().forEach(System.out::println);
	}

	private Subject addSubject() {	
		Subject subject = new Subject();;
		subject.setSubjectId(Long.parseLong(gatValFromConsole("enter subject id")));
		subject.setSubTitle(gatValFromConsole("enter subject title"));
		subject.setDurationInHours(Integer.parseInt(gatValFromConsole("enter duration In Hours)")));
		System.out.println(subject.toString());
		return subject;
	}
	
	
	private long deleteSubject() {
	long subjectId=Long.parseLong(gatValFromConsole("enter the subject id to be eleted"));			
	return subjectId;
	}

	
	private long searchSubject() {
	long subjectId=Long.parseLong(gatValFromConsole("enter the subject id for search"));
		return subjectId;
	}
	
	
	private Book addBook() {	
		Book book = new Book();		
		book.setBookId(Long.parseLong(gatValFromConsole("enter book id")));
		book.setTitle(gatValFromConsole("enter book title"));
		book.setPrice(Integer.parseInt(gatValFromConsole("enter book price")));
		book.setVolume(Integer.parseInt(gatValFromConsole("enter book volume")));
book.setPublishDate(LocalDate.parse(gatValFromConsole("enter book publish date(yyyy-mm-dd) ")));
		System.out.println(book.toString());
		return book;
	}
	
	
	private long deleteBook() {
	long bookId=Long.parseLong(gatValFromConsole("enter the book id to be deleted"));
		return bookId;
	}
	
	
	private long searchBook() {
		long bookId=Long.parseLong(gatValFromConsole("enter the book id for search "));
		return bookId;
	}

	
	private String gatValFromConsole(String log) {
		System.out.println(log);
		String inputString = "";
		try {
	BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			inputString = bufferRead.readLine();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return inputString;
	}
	
	
	private void exit() {
		System.exit(0);
	}
	
}
