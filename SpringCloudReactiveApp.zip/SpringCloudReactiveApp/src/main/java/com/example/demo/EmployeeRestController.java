package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/employees")
public class EmployeeRestController 
{
@Autowired
private EmployeeService service;

@PostMapping
public Mono<Employee> saveEmployee(@RequestBody Employee employee)
{
	return service.saveEmployee(employee);
}

@GetMapping("/{empid}")
public Mono<Employee> getOneEmployee(@PathVariable String empid)
{
	return service.fetchOneEmployee(empid);
}

@GetMapping
public Flux<Employee> getAllEmployee()
{
	return service.fetchAllEmployee();
}

@DeleteMapping("/{empid}")
public Mono<Void> removeEmployee(@PathVariable String empid)
{
	return service.deleteEnmployee(empid);
}
}
