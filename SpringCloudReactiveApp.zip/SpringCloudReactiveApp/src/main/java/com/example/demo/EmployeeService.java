package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EmployeeService 
{
@Autowired
private EmployeeRepository repo;

public Mono<Employee> saveEmployee(Employee s)
{
	return repo.save(s);	
}

public Mono<Employee> fetchOneEmployee(String empid)
{
	return repo.findById(empid).switchIfEmpty(Mono.empty());
}

public Flux<Employee> fetchAllEmployee()
{
	return repo.findAll().switchIfEmpty(Flux.empty());
}

public Mono<Void> deleteEnmployee (String empid)
{
	return repo.deleteById(empid);
}
}


