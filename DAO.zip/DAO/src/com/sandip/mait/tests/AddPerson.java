package com.sandip.mait.tests;

import com.sandip.mait.dao.DaoException;
import com.sandip.mait.dao.PersonDao;
import com.sandip.mait.dao.impl.JdbcPersonDao;
import com.sandip.mait.entity.Person;

public class AddPerson 
{
public static void main(String[] args) throws DaoException
{
Person person =new Person(101,"sandip","kumar","9988776655","sandip@gmail.com");
PersonDao dao=new JdbcPersonDao();
dao.addPerson(person);
System.out.println("Person data added");
}
}
