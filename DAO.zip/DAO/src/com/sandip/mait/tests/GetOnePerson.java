package com.sandip.mait.tests;

import com.sandip.mait.dao.DaoException;
import com.sandip.mait.dao.PersonDao;
import com.sandip.mait.dao.impl.JdbcPersonDao;
import com.sandip.mait.entity.Person;

public class GetOnePerson 
{
public static void main(String[] args) throws DaoException
{
PersonDao dao=new JdbcPersonDao();
int id=101;
Person p=dao.getPerson(id);
if(p==null)
System.out.println("Person data not there");
else
	System.out.println(p);
}
}
