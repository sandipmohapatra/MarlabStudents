package com.sandip.mait.tests;

import com.sandip.mait.dao.DaoException;
import com.sandip.mait.dao.PersonDao;
import com.sandip.mait.dao.impl.JdbcPersonDao;
import com.sandip.mait.entity.Person;

public class DeletePerson 
{
public static void main(String[] args) throws DaoException
{
PersonDao dao=new JdbcPersonDao();
int id=101;
dao.deletePerson(id);
System.out.println("Person data deleted");
}
}
