package in.sandip.service;

import java.util.List;

import in.sandip.entity.Company;

public interface ICompanyService {

	Long createCompany(Company cob);
	void updateCompany(Company cob);
	Company getOneCompany(Long id);
	List<Company> getAllCompanies();
}
