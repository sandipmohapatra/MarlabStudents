package in.sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sandip.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Long> {

}
