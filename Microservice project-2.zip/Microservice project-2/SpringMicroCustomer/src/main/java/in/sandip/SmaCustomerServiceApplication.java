package in.sandip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmaCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmaCustomerServiceApplication.class, args);
	}

}
