package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.discovery.EurekaClient;

@Component
public class ConsumeService {
	@Autowired
	private DiscoveryClient client;
	public String calladdressMethods()
	{
		List<ServiceInstance> list = client.getInstances("ADDRESS-SERVICE");
		ServiceInstance si=list.get(0);
		String url=si.getUri() +"/address/show";
		RestTemplate rt=new RestTemplate();
		String x=rt.getForObject(url, String.class);
		System.out.println(list);
		return x;
	}


	public String callbankMethods() 
	{
		List<ServiceInstance> list1 =client.getInstances("BANK-SERVICE"); 
		ServiceInstance si1=list1.get(0);
			String url1=si1.getUri() +"/bank/details"; 
			RestTemplate rt=new RestTemplate(); 
			String y=rt.getForObject(url1, String.class); 
			return y;

	}


}
