package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.ConsumeService;
@RestController
@RequestMapping("/cust")
public class AccessController 
{
	@Autowired
	private ConsumeService cons;
	
@GetMapping("/access")
public String showMsg()
{
	String detail="My Address details"+ cons.calladdressMethods();
	String detail1="My Bank details"+ cons.callbankMethods();
		return (detail + " "+detail1);
	
}
}
